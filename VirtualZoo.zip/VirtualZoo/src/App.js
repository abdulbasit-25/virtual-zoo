// src/App.js
import React from "react";
import "./App.css";

import Home from "./components/Home";
import About from "./components/About";
import Header from "./components/Header";
import Animals from "./components/Animals";
import Footer from "./components/Footer";
import ContactUs from "./components/ContactUs";
import WhatsApp from "./components/WhatsApp";

import Events from "./components/Events";
import ZooMap from "./components/ZooMap";
import Blog from "./components/Blog";
import KidsCorner from "./components/KidsCorner";
import FAQ from "./components/FAQ";

function App() {
  return (
    <div>
      <WhatsApp />
      <Header />
      <Home />
      <About />
      <Animals />
      <Events />
      <ZooMap />
      <Blog />
      <KidsCorner />
      <FAQ />
      <ContactUs />
      <Footer />
    </div>
  );
}

export default App;
