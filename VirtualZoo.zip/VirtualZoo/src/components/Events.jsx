import React, { useState } from "react";
import "../css/Events.css";

const eventList = [
  { title: "🦁 Lion Feeding Show", time: "2:00 PM" },
  { title: "🦜 Parrot Talk", time: "4:00 PM" },
  { title: "🐍 Snake Awareness", time: "6:00 PM" },
];

function Event() {
  const [name, setName] = useState("");
  const [qty, setQty] = useState(1);
  const [success, setSuccess] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    setSuccess(`🎟️ Ticket booked for ${name} - ${qty} person(s)!`);
    setName("");
    setQty(1);
  };

  return (
    <div id="events" className="event-section">
      {/* Left Column - Events */}{" "}
      <div className="event-ticket-container">
        <div className="events">
          <h2>🎉 Zoo Events</h2>
          <ul>
            {eventList.map((e, i) => (
              <li key={i}>
                <strong>{e.title}</strong> <span>- {e.time}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Right Column - Ticket Booking */}
        <div className="tickets">
          <h2>🎟️ Book Tickets / Donate 💰</h2>
          <form onSubmit={handleSubmit}>
            <input
              type="text"
              placeholder="Your Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
            <input
              type="number"
              min="1"
              max="10"
              value={qty}
              onChange={(e) => setQty(e.target.value)}
            />
            <button type="submit">Book Now</button>
          </form>
          {success && <p className="success-message">{success}</p>}
        </div>
      </div>
    </div>
  );
}

export default Event;
