import React from "react";
import "../css/Header.css";
import Logo from "../assets/images/logo.png"; // Logo import

const Header = () => {
  return (
    <header className="header" role="banner">
      <div className="logo">
        <a href="#home" className="logo-link" aria-label="Virtual Zoo Home">
          <img src={Logo} alt="Virtual Zoo Logo" className="logo-img" />
          <span className="logo-text">Virtual Zoo</span>
        </a>
      </div>

      <nav className="nav" role="navigation" aria-label="Primary Navigation">
        <ul className="nav-list">
          <li>
            <a href="home-container" className="nav-item">
              Home
            </a>
          </li>
          <li>
            <a href="#about" className="nav-item">
              About
            </a>
          </li>
          <li>
            <a href="#animals" className="nav-item">
              Animals
            </a>
          </li>
          <li>
            <a href="#events" className="nav-item">
              Events
            </a>
          </li>
          <li>
            <a href="#zoomap" className="nav-item">
              Zoo Map
            </a>
          </li>

          <li>
            <a href="#zoo-contact-section" className="nav-item">
              Contact
            </a>
          </li>
        </ul>
      </nav>
    </header>
  );
};

export default Header;
