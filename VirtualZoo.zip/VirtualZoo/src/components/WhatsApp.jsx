import React from "react";
import WhatsAppLogo from "../assets/images/WhatsApp.png"; // Import the image
import "../css/WhatsApp.css"; // Add styles for the component
const WhatsApp = () => {
  const phoneNumber = "03415878569";
  const whatsappLink = `https://wa.me/${phoneNumber}`;

  return (
    <a
      href={whatsappLink}
      target="_blank"
      rel="noopener noreferrer"
      className="floating-btn"
      title="Chat with us on WhatsApp" // Tooltip added here
    >
      <img src={WhatsAppLogo} alt="WhatsApp" className="whatsapp-img" />
    </a>
  );
};

export default WhatsApp;
