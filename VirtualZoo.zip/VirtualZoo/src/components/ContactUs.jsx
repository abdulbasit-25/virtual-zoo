import React from "react";
import "../css/ContactUs.css";

const ContactUs = () => {
  return (
    <section id="zoo-contact-section">
      <div className="zoo-contact-container">
        <div className="zoo-contact-content">
          {/* Contact Form Section */}
          <div className="zoo-contact-form-section">
            <h1 style={{ fontSize: "48px" }}>CONTACT US</h1>

            <h2>Get in Touch with the Zoo!</h2>

            {/* Contact Form */}
            <form>
              <div className="zoo-form-group">
                <label htmlFor="name">Name</label>
                <input type="text" id="name" name="name" />
              </div>

              <div className="zoo-form-group">
                <label htmlFor="email">Email*</label>
                <input type="email" id="email" name="email" required />
              </div>

              <div className="zoo-form-group">
                <label htmlFor="message">Message</label>
                <textarea id="message" name="message" rows="6"></textarea>
              </div>

              <div className="zoo-form-attachments">
                <a href="#" className="zoo-attach-files">
                  <i className="fas fa-paperclip"></i> Attach Files
                </a>
                <span>Attachments (0)</span>
              </div>

              <button type="submit" className="zoo-send-button">
                Send
              </button>
            </form>

            <p className="zoo-recaptcha-notice">
              This site is protected by reCAPTCHA and the Google Privacy Policy
              and Terms of Service apply.
            </p>
          </div>

          {/* Contact Info Section */}
          <div className="zoo-contact-info-section">
            <h2>We'd Love to Hear From You!</h2>
            <p>
              Whether you're interested in our animals, educational programs, or
              special events, we're here to help. Share your thoughts, feedback,
              or questions with us!
            </p>

            {/* Social Media Buttons */}
            <div className="zoo-social-buttons">
              <a
                href="https://wa.me/03415878569"
                className="zoo-whatsapp-button"
              >
                <i className="fab fa-whatsapp"></i> WhatsApp Us
              </a>

              <a
                href="https://www.instagram.com/__abdul.basitt"
                className="zoo-instagram-button"
              >
                <i className="fab fa-instagram"></i> Follow Us on Instagram
              </a>
            </div>

            {/* Zoo Info Section */}
            <div className="zoo-info">
              <p>Phone: +92 341 5878569</p>
              <p className="zoo-location">Location: Pakistan, Islamabad</p>
            </div>
            <div className="zoo-visitor-info-email">
              <a href="mailto:visits@ourzoo.com">
                <i className="fas fa-envelope"></i> Email Us for Visitor Info
              </a>
            </div>
            {/* Email Links */}
            <div className="zoo-archer-insight-signature">
              <span>
                <i className="fas fa-signature"></i> A.R.C.H.E.R.
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactUs;
