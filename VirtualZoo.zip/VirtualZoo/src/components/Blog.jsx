import React from "react";
import "../css/Blog.css"; // Import CSS

const posts = [
  {
    title: "Top 5 Fastest Animals",
    content:
      "Cheetah, Falcon, Sailfish, Pronghorn Antelope, Swordfish. These creatures showcase the extreme limits of speed in the animal kingdom!",
  },
  {
    title: "Why Protect Tigers?",
    content:
      "Tigers are endangered due to poaching and habitat loss. Protecting them helps maintain biodiversity and balance in ecosystems.",
  },
  {
    title: "Fun Facts About Parrots",
    content:
      "Parrots can mimic human speech, live for decades, and are among the smartest birds in the world!",
  },
];

function Blog() {
  return (
    <div className="blog">
      <h2 className="blog-title">Zoo Blog ✍️</h2>
      <div className="blog-container">
        {posts.map((p, i) => (
          <div key={i} className="post">
            <h3 className="post-title">{p.title}</h3>
            <p className="post-content">{p.content}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Blog;
