import React, { useState } from "react";
import "../css/KidsCorner.css";
import Giraffa from "../assets/images/Giraffa.jpg";

const quizQuestions = [
  {
    question: "Who hunts better at night?",
    options: ["Owl", "Eagle", "Bat", "Fox"],
    answer: "Owl",
    explanation: "Owls are nocturnal hunters with excellent night vision! 🦉🌙",
  },
  {
    question: "Which animal has three hearts?",
    options: ["Octopus", "Shark", "Frog", "Dog"],
    answer: "Octopus",
    explanation: "Octopuses have three hearts and blue blood! 💙🐙",
  },
];

function KidsCorner() {
  const [quizStep, setQuizStep] = useState(0);
  const [quizAnswer, setQuizAnswer] = useState(null);
  const [showJokePunchline, setShowJokePunchline] = useState(false);
  const [funFactFlipped, setFunFactFlipped] = useState(false);
  const [userCreation, setUserCreation] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const currentQuiz = quizQuestions[quizStep];

  const handleQuiz = (option) => {
    if (option === currentQuiz.answer) {
      setQuizAnswer({
        correct: true,
        text: "Correct! " + currentQuiz.explanation,
      });
    } else {
      setQuizAnswer({ correct: false, text: "Oops! Try again." });
    }
  };

  const nextQuiz = () => {
    setQuizStep((prev) => (prev + 1) % quizQuestions.length);
    setQuizAnswer(null);
  };

  const toggleJoke = () => {
    setShowJokePunchline((prev) => !prev);
  };

  const toggleFunFact = () => {
    setFunFactFlipped((prev) => !prev);
  };

  const handleSubmit = () => {
    if (userCreation.trim().length > 0) {
      setSubmitted(true);
      setUserCreation("");
      setTimeout(() => setSubmitted(false), 4000);
    }
  };

  return (
    <div className="kids-corner" aria-label="Kids corner interactive section">
      <h2> Kids’ Corner </h2>

      <div className="section-grid">
        {/* Fun Fact with flip */}
        <div
          className={`section fact-box ${funFactFlipped ? "flipped" : ""}`}
          onClick={toggleFunFact}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => e.key === "Enter" && toggleFunFact()}
          aria-pressed={funFactFlipped}
          aria-label="Fun fact card. Press enter or click to flip for more info."
        >
          {!funFactFlipped ? (
            <>
              <h3>🐘 Fun Fact</h3>
              <p>Elephants can recognize themselves in a mirror!</p>
              <small>Click to learn more →</small>
            </>
          ) : (
            <>
              <h3>🐘 Fun Fact (More)</h3>
              <p>
                This shows elephants have self-awareness — a sign of high
                intelligence similar to humans!
              </p>
              <small>Click to flip back ←</small>
            </>
          )}
        </div>

        {/* Animal of the Day with image */}
        <div
          className="section animal-box"
          aria-label="Animal of the day: Giraffe"
        >
          <h3>🦒 Animal of the Day</h3>
          <img
            src={Giraffa}
            alt="Giraffe eating leaves"
            style={{
              maxWidth: "100%",
              borderRadius: "12px",
              marginBottom: "8px",
            }}
          />
          <p>
            <strong>Giraffe:</strong> Their tongues can be 18–20 inches long!
            Perfect for reaching high leaves.
          </p>
        </div>

        {/* Joke with toggle punchline */}
        <div className="section joke-box">
          <h3>😂 Joke Time</h3>
          <p>
            <em>Why don’t lions play cards in the wild?</em>
          </p>
          <button
            className="quiz-buttons"
            onClick={toggleJoke}
            aria-expanded={showJokePunchline}
            aria-controls="joke-punchline"
          >
            {showJokePunchline ? "Hide Punchline" : "Show Punchline"}
          </button>
          {showJokePunchline && (
            <p
              id="joke-punchline"
              style={{ marginTop: "8px", fontWeight: "bold" }}
            >
              Because there are too many cheetahs! 🐆
            </p>
          )}
        </div>

        {/* Quiz with multiple questions */}
        <div className="section quiz-box" aria-live="polite" aria-atomic="true">
          <h3>🧠 Quiz Time</h3>
          <p>{currentQuiz.question}</p>
          <div className="quiz-buttons" role="group" aria-label="Quiz options">
            {currentQuiz.options.map((option) => (
              <button
                key={option}
                onClick={() => handleQuiz(option)}
                disabled={quizAnswer?.correct}
                aria-disabled={quizAnswer?.correct}
              >
                {option}
              </button>
            ))}
          </div>
          {quizAnswer && (
            <p
              className="quiz-answer"
              style={{
                color: quizAnswer.correct ? "green" : "red",
                marginTop: "10px",
              }}
            >
              {quizAnswer.text}
            </p>
          )}
          {quizAnswer?.correct && (
            <button
              className="quiz-buttons"
              onClick={nextQuiz}
              aria-label="Next quiz question"
              style={{ marginTop: "10px" }}
            >
              Next Question ➡️
            </button>
          )}
        </div>

        {/* Call to action with textarea */}
        <div className="section call-to-action">
          <h3>🖍️ Create Your Own Fun!</h3>
          <p>
            Draw your favorite animal or write your own fun fact! Share it with
            your family or teacher!
          </p>
          <textarea
            rows="4"
            placeholder="Write your fun fact or describe your drawing here..."
            value={userCreation}
            onChange={(e) => setUserCreation(e.target.value)}
            aria-label="User creative input"
          />
          <button
            onClick={handleSubmit}
            disabled={userCreation.trim() === ""}
            aria-disabled={userCreation.trim() === ""}
            style={{ marginTop: "10px" }}
          >
            Submit
          </button>
          {submitted && (
            <p style={{ color: "green", marginTop: "8px" }}>
              Thanks for sharing your creativity! 🎉
            </p>
          )}
        </div>

        {/* Did you know */}
        <div className="section didyouknow-box">
          <h3>🔍 Did You Know?</h3>
          <p>Octopuses have three hearts and blue blood! 💙🐙</p>
        </div>
      </div>
    </div>
  );
}

export default KidsCorner;
