import React, { useRef } from "react";
import "../css/ZooMap.css";
import zooMap from "../assets/images/zoo.jpg";

function ZooMap() {
  const containerRef = useRef(null);

  const handleMouseMove = (e) => {
    const container = containerRef.current;
    const rect = container.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    container.style.setProperty("--x", `${x}px`);
    container.style.setProperty("--y", `${y}px`);
  };

  const handleMouseLeave = () => {
    const container = containerRef.current;
    container.style.setProperty("--x", `-9999px`);
    container.style.setProperty("--y", `-9999px`);
  };

  return (
    <section id="zoomap" className="zoo-map">
      <div
        className="zoo-map__container"
        ref={containerRef}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
      >
        <h2 className="zoo-map__title">
          Zoo Map{" "}
          <span role="img" aria-label="map">
            🗺️
          </span>
        </h2>
        <img src={zooMap} alt="Zoo Map" className="zoo-map__blurred" />
        <img
          src={zooMap}
          alt="Unblurred Spotlight"
          className="zoo-map__sharp"
        />
      </div>
    </section>
  );
}

export default ZooMap;
