import React, { useState } from "react";
import "../css/FAQ.css";

function FAQ() {
  const faqs = [
    {
      q: "Is the zoo open 24/7 online?",
      a: "Yes, it's a virtual zoo! You can explore anytime, anywhere 🌍.",
    },
    {
      q: "How many animals are there?",
      a: "We have over 100+ species from around the world 🐘🦜.",
    },
    {
      q: "Can I suggest new animals?",
      a: "Of course! We love suggestions. Share your ideas with us 💡.",
    },
    { q: "Is this free?", a: "Yes! Our virtual zoo is completely free 🎉." },
  ];

  const [activeIndex, setActiveIndex] = useState(null);

  const toggleFAQ = (index) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  return (
    <div className="faq">
      <h2>❓ Frequently Asked Questions</h2>
      <div className="faq-list">
        {faqs.map((f, i) => (
          <div
            key={i}
            className={`faq-item ${activeIndex === i ? "active" : ""}`}
            onClick={() => toggleFAQ(i)}
          >
            <div className="faq-question">
              <span>Q: {f.q}</span>
              <span className="faq-icon">{activeIndex === i ? "−" : "+"}</span>
            </div>
            {activeIndex === i && <p className="faq-answer">A: {f.a}</p>}
          </div>
        ))}
      </div>
    </div>
  );
}

export default FAQ;
