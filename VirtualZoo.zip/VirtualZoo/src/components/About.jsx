import React from "react";
import "../css/About.css";

const About = () => {
  return (
    <section id="about">
      <div className="about-container1">
        <div className="about-container">
          {/* About Section */}
          <section className="about">
            <h2>About Our Zoo</h2>
            <div className="AboutBox">
              <p>
                Welcome to our zoo! We are committed to wildlife conservation
                and creating an unforgettable experience for every visitor. Our
                mission is to protect endangered species, educate the public
                about the importance of biodiversity, and offer a
                family-friendly environment for learning and fun.
              </p>
            </div>
          </section>

          {/* What We Offer */}
          <section className="what-we-offer">
            <h2>What We Offer</h2>
            <div className="offerings">
              <div className="offering">
                <h3>Wildlife Education</h3>
                <p>
                  Our zoo provides interactive and educational programs designed
                  to raise awareness about the importance of wildlife
                  conservation and biodiversity.
                </p>
              </div>
              <div className="offering">
                <h3>Guided Tours</h3>
                <p>
                  Explore the zoo with our expert guides who will share
                  fascinating facts about the animals and their natural
                  habitats. Ideal for schools, groups, and families.
                </p>
              </div>
              <div className="offering">
                <h3>Special Exhibits</h3>
                <p>
                  Throughout the year, we host special exhibits showcasing
                  unique species and conservation efforts from around the world.
                  Keep an eye out for seasonal events!
                </p>
              </div>
            </div>
          </section>

          {/* Services Section */}
          <section className="services">
            <h2>Our Services</h2>
            <div className="service-list">
              <div className="service-item">
                <h3>Zoo Membership</h3>
                <p>
                  Become a member to enjoy unlimited access to the zoo,
                  discounts on events, and early access to special exhibits.
                </p>
              </div>
              <div className="service-item">
                <h3>Birthday Parties</h3>
                <p>
                  Celebrate your child’s birthday at the zoo! We offer birthday
                  party packages complete with animal encounters, decorations,
                  and entertainment.
                </p>
              </div>
              <div className="service-item">
                <h3>Animal Encounters</h3>
                <p>
                  Get up close and personal with some of our friendly animals
                  through guided animal encounters. A memorable experience for
                  all ages!
                </p>
              </div>
            </div>
          </section>
        </div>
      </div>
    </section>
  );
};

export default About;
