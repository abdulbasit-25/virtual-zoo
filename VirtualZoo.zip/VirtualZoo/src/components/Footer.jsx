// src/components/Footer.jsx
import React from "react";
import "../css/Footer.css";
import F_Logo from "../assets/images/logo.png"; // Importing the logo

const Footer = () => {
  return (
    <footer className="footer-container">
      <div className="footer-content">
        {/* Logo Section */}
        <div className="footer-logo">
          <img src={F_Logo} alt="Zoo Park Logo" className="footer-logo-img" />
        </div>

        {/* Navigation Links */}
        <nav className="footer-links" aria-label="Footer Navigation">
          <ul>
            <li>
              <a href="#" title="Go to Home page">
                Home
              </a>
            </li>
            <li>
              <a href="#" title="Learn more About Zoo Park">
                About
              </a>
            </li>
            <li>
              <a href="#" title="Explore Animals at Zoo Park">
                Animals
              </a>
            </li>
            <li>
              <a href="#" title="Contact Zoo Park">
                Contact
              </a>
            </li>
          </ul>
        </nav>

        {/* Social Media Links */}
        <div className="footer-social">
          <ul>
            <li>
              <a
                href="#"
                target="_blank"
                rel="noopener noreferrer"
                title="Visit Zoo Park on Facebook"
              >
                Facebook
              </a>
            </li>
            <li>
              <a
                href="#"
                target="_blank"
                rel="noopener noreferrer"
                title="Follow Zoo Park on Twitter"
              >
                Twitter
              </a>
            </li>
            <li>
              <a
                href="#"
                target="_blank"
                rel="noopener noreferrer"
                title="Follow Zoo Park on Instagram"
              >
                Instagram
              </a>
            </li>
          </ul>
        </div>
      </div>

      {/* Footer Bottom */}
      <div className="footer-bottom">
        <p>&copy; {new Date().getFullYear()} Zoo Park. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;
