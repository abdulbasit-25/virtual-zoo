// src/components/Home.jsx
import React from "react";
import "../css/Home.css";

const Home = () => {
  return (
    <div className="home-container">
      {/* main Section */}
      <section className="main">
        <div className="main-text">
          <h1>Welcome to the Virtual Zoo 🐾</h1>
          <p>
            Discover amazing animals, learn about their habitats, and explore
            the wonders of wildlife — all in one place!
          </p>
          <button className="explore-btn">Explore Now</button>
        </div>
      </section>
    </div>
  );
};

export default Home;
