// src/components/Animals.jsx
import React, { useState } from "react";
import "../css/Animals.css";

// Importing images
import Lion from "../assets/images/Lion.jpg";
import Elephant from "../assets/images/Elephant.jpg";
import Panda from "../assets/images/Panda.jpg";
import Zebra from "../assets/images/Zebra.jpg";
import Leopard from "../assets/images/Leopard.jpg";
import Bear from "../assets/images/Bear.jpg";
import Tiger from "../assets/images/Tiger.jpg";
import Deer from "../assets/images/Deer.jpg";
import Snake from "../assets/images/Snake.jpg";
import Giraffa from "../assets/images/Giraffa.jpg";

// New Birds
import Columbidae from "../assets/images/Columbidae.jpg";
import Macaw from "../assets/images/Macaw.jpg";
import Budgerigar from "../assets/images/Budgerigar.jpg";
import BlueJay from "../assets/images/BlueJay.jpeg";

// Animal data (with type for filtering)
const animalData = [
  {
    name: "Lion",
    type: "Mammal",
    img: Lion,
    desc: "The King of the Jungle, symbol of courage and strength.",
  },
  {
    name: "Elephant",
    type: "Mammal",
    img: Elephant,
    desc: "The gentle giant known for intelligence and memory.",
  },
  {
    name: "Panda",
    type: "Mammal",
    img: Panda,
    desc: "Adorable bamboo lovers, ambassadors of wildlife conservation.",
  },
  {
    name: "Zebra",
    type: "Mammal",
    img: Zebra,
    desc: "Black and white striped creatures with strong herd mentality.",
  },
  {
    name: "Leopard",
    type: "Mammal",
    img: Leopard,
    desc: "Graceful and powerful big cat, known for its agility.",
  },
  {
    name: "Bear",
    type: "Mammal",
    img: Bear,
    desc: "Mighty predator, known for strength and love for the wild.",
  },
  {
    name: "Tiger",
    type: "Mammal",
    img: Tiger,
    desc: "Large, powerful, and majestic big cats, kings of the wild.",
  },
  {
    name: "Deer",
    type: "Mammal",
    img: Deer,
    desc: "Graceful herbivores, elegant and speedy in the wild.",
  },
  {
    name: "Snake",
    type: "Reptile",
    img: Snake,
    desc: "Slithering reptiles known for their agility and mystery.",
  },
  {
    name: "Columbidae",
    type: "Bird",
    img: Columbidae,
    desc: "Pigeons and doves, symbols of peace found worldwide.",
  },
  {
    name: "Macaw",
    type: "Bird",
    img: Macaw,
    desc: "Colorful parrots known for intelligence and loud calls.",
  },
  {
    name: "Budgerigar",
    type: "Bird",
    img: Budgerigar,
    desc: "Small parrots, playful and popular as pet birds.",
  },
  {
    name: "Blue Jay",
    type: "Bird",
    img: BlueJay,
    desc: "Vibrant blue birds known for intelligence and mimicry.",
  },
  {
    name: "Giraffe",
    type: "Mammal",
    img: Giraffa,
    desc: "Vibrant blue birds known for intelligence and mimicry.",
  },
];

const Animals = () => {
  const [filter, setFilter] = useState("All");

  const filteredAnimals =
    filter === "All" ? animalData : animalData.filter((a) => a.type === filter);

  return (
    <section id="animals">
      <div className="Animals-container">
        <section className="featured-animals">
          <h2>Meet Our Animals</h2>

          {/* Filter Buttons */}
          <div className="filter-buttons">
            <input
              type="radio"
              id="all"
              name="filter"
              value="All"
              checked={filter === "All"}
              onChange={() => setFilter("All")}
            />
            <label htmlFor="all">All</label>

            <input
              type="radio"
              id="mammal"
              name="filter"
              value="Mammal"
              checked={filter === "Mammal"}
              onChange={() => setFilter("Mammal")}
            />
            <label htmlFor="mammal">Mammals</label>

            <input
              type="radio"
              id="bird"
              name="filter"
              value="Bird"
              checked={filter === "Bird"}
              onChange={() => setFilter("Bird")}
            />
            <label htmlFor="bird">Birds</label>

            <input
              type="radio"
              id="reptile"
              name="filter"
              value="Reptile"
              checked={filter === "Reptile"}
              onChange={() => setFilter("Reptile")}
            />
            <label htmlFor="reptile">Reptiles</label>
          </div>

          {/* Animal Cards */}
          <div className="animal-cards">
            {filteredAnimals.map((animal, index) => (
              <div key={index} className="animal-card">
                <img src={animal.img} alt={animal.name} />
                <h3>{animal.name}</h3>
                <p>{animal.desc}</p>
              </div>
            ))}
          </div>
        </section>
      </div>
    </section>
  );
};

export default Animals;
